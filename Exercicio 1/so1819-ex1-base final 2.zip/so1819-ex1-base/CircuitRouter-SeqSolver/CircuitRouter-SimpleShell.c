#include <stdio.h>
#include <stdlib.h>
#include <string.h>


void launchSolver(char *fileName);

int main(int argc, char** argv){
  const char EXIT_COMMAND[4] = "exit";
  const char RUN_COMMAND[3] = "run";
  char fileName[200];
  char str[200];
  const char s[2] = " ";
  char *token;
  
  while(1){
    //get the text
    puts("input the run command followed by the file:");
    fgets(str,sizeof(str),stdin);

    /* get the first token */
    token = strtok(str, s);
    if(strncmp(token,EXIT_COMMAND,4)==0)
        break;
    if(strncmp(token,RUN_COMMAND,3)==0){
        token = strtok(NULL, s);
        strcpy(fileName, token);
        launchSolver(fileName);
    } else {
        puts("Wrong command!");
    }
  }
  printf("Exited Simple Shell.\n");
  return 0;
}

void launchSolver(char *fileName){
  int thread;
  thread = fork();
  if(thread==0){
    //com execl não da erro mas também não funciona.
    execv("CircuitRouter-SeqSolver",fileName);
    printf("\nshould never print this!");
    exit(-1);
  }
  else{
    printf("\nInside the main process!\n");
  }
}