#include <stdio.h>
#include <stdlib.h>
#include <string.h>


void launchSolver(char *fileName);

int main(int argc, char** argv){
    const char EXIT_COMMAND[4] = "exit";
    const char RUN_COMMAND[3] = "run";
    const char DELIM[1] = " ";
    int MAXCHILDREN = (int)argv[0];
    char inputedData[500];
    while(1){
        puts("Input the file:");
        scanf("%s",inputedData);
        if(strncmp(inputedData, EXIT_COMMAND, 1)==0)
            break;
        else
            launchSolver(inputedData);
    }
    printf("Exited Simple Shell.\n");
    return 0;
}

void launchSolver(char *fileName){
  int thread;
  thread = fork();
  if(thread==0){
    //com execl não da erro mas também não funciona.
    execv("CircuitRouter-SeqSolver",fileName);
    printf("\nshould never print this!");
    exit(-1);
  }
  else{
    printf("\nInside the main process!\n");
  }
}